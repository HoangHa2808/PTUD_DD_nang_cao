import { Drink } from "./drink.model";

export interface Category{
    id: number;
    label: string;
    image: string;
    active: boolean;
}