export interface Drink{
    id: number;
    idCate: number;
    title: string;
    image: string;
    description: string;
    ingredient: string;
    material: string;
    finished: string;
}