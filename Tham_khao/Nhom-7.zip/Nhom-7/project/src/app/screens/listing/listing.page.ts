import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Category } from 'src/app/models/category.model';
import { Drink } from 'src/app/models/drink.model';
import { DrinkService } from 'src/app/services/drink.service';
import { ActivatedRoute } from '@angular/router';
import { CategoryService } from 'src/app/services/category.service';

@Component({
  selector: 'app-listing',
  templateUrl: './listing.page.html',
  styleUrls: ['./listing.page.scss'],
})
export class ListingPage implements OnInit {

  searchTerm: string;
  drinks: Drink[] = [];
  categories: Category[] = [];

  constructor(private drinkService: DrinkService, private categoryService: CategoryService, private router: Router, private activatedRouter: ActivatedRoute) { }

  ngOnInit() { 
    this.drinks=this.drinkService.getDrinks();
    this.categories=this.categoryService.getCategory();
  }
  getCategory(idCate: number){
    
      this.router.navigate(['drink', idCate])
    
    
  }

  goToDetailPage(id: number){
    this.router.navigate(['detail', id]);
  }

}