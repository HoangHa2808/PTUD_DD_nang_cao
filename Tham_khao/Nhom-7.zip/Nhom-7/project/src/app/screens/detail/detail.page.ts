import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Drink } from 'src/app/models/drink.model';
import { DrinkService } from 'src/app/services/drink.service';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.page.html',
  styleUrls: ['./detail.page.scss'],
})
export class DetailPage implements OnInit {
  drink: Drink;
  constructor(private activatedRouter: ActivatedRoute, private drinkService: DrinkService) { 
    const id = +this.activatedRouter.snapshot.paramMap.get('id');
    this.drink=this.drinkService.getDrink(id);
  }

  ngOnInit() {
    
  }

}
