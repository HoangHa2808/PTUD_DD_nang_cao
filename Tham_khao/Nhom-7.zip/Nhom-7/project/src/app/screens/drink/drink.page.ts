import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Category } from 'src/app/models/category.model';
import { Drink } from 'src/app/models/drink.model';
import { CategoryService } from 'src/app/services/category.service';
import { DrinkService } from 'src/app/services/drink.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-drink',
  templateUrl: './drink.page.html',
  styleUrls: ['./drink.page.scss'],
})
export class DrinkPage implements OnInit {

  drinks: Drink[] = [];
  cate:Category;
  constructor(private activatedRouter: ActivatedRoute,private router: Router, private drinkService: DrinkService, private cateService:CategoryService) {
   }
  ngOnInit() {
    this.getDrinkByCate();
    this.getNameCate();
  }
  getDrinkByCate(){
    
    const id = +this.activatedRouter.snapshot.paramMap.get('idCate');
    this.drinks=this.drinkService.getDrinks().filter((x) => 
      x.idCate === id
    )
  }
  getNameCate(){
    const id = +this.activatedRouter.snapshot.paramMap.get('idCate');
    this.cate = this.cateService.getCategories(id);
    return this.cate.label;
  }
  goToDetailPage(id: number){
    this.router.navigate(['detail', id]);
  }
}
