import { Injectable, OnInit } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { Category } from "../models/category.model";
import { Drink } from "../models/drink.model";

@Injectable({
    providedIn: 'root'
})
export class CategoryService{
  drink:Drink[];
    getCategory():Category[] {
        return[
              {
                id: 1,
                label:'Cà Phê',
                image:'assets/icon/Coffee.png',
                active: false,
              },
              {
                id: 2,
                label:'Trà',
                image:'assets/icon/Tea.png',
                active: false,
              },
              {
                id: 3,
                label:'Smoothie',
                image:'assets/icon/iceblend.png',
                active: false,
              },
              {
                  id: 4,
                  label:'Trà Sữa',
                  image: 'assets/icon/milktea.png',
                  active: false,
              },
              
        ]
    }
    getCategories(id:number):Category{
      return this.getCategory().filter((cate) => cate.id === id)[0];
    }

    
}