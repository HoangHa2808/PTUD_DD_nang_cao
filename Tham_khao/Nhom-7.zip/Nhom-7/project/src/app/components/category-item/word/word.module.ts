import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { IonicModule } from "@ionic/angular";
import { WordComponent } from "./word.component";

@NgModule({
    declarations:[WordComponent],
    imports: [CommonModule, IonicModule],
    exports: [WordComponent],
})
export class WordModule{}