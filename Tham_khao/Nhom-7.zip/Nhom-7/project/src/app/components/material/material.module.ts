import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { IonicModule } from "@ionic/angular";
import { MaterialComponent } from "./material.component";
@NgModule({
    declarations:[MaterialComponent],
    imports: [CommonModule, IonicModule],
    exports: [MaterialComponent],
})
export class CategoryItemModule{}
