import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { IonicModule } from "@ionic/angular";
import { DrinkCardComponent } from "./drink-card.component";
@NgModule({
    declarations:[DrinkCardComponent],
    imports: [CommonModule, IonicModule],
    exports: [DrinkCardComponent]
})
export class DrinkCardModule{}