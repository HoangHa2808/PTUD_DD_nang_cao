import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hotro',
  templateUrl: './hotro.page.html',
  styleUrls: ['./hotro.page.scss'],
})
export class HotroPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
