import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gioithieu',
  templateUrl: './gioithieu.page.html',
  styleUrls: ['./gioithieu.page.scss'],
})
export class GioithieuPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
