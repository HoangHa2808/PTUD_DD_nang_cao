import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hopdong',
  templateUrl: './hopdong.page.html',
  styleUrls: ['./hopdong.page.scss'],
})
export class HopdongPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
