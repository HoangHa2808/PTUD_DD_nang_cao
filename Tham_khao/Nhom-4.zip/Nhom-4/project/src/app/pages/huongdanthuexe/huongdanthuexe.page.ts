import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-huongdanthuexe',
  templateUrl: './huongdanthuexe.page.html',
  styleUrls: ['./huongdanthuexe.page.scss'],
})
export class HuongdanthuexePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
