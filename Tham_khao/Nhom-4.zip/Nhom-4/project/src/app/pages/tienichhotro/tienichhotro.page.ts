import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tienichhotro',
  templateUrl: './tienichhotro.page.html',
  styleUrls: ['./tienichhotro.page.scss'],
})
export class TienichhotroPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
