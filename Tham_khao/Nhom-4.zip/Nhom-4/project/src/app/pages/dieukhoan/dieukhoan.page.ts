import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dieukhoan',
  templateUrl: './dieukhoan.page.html',
  styleUrls: ['./dieukhoan.page.scss'],
})
export class DieukhoanPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
