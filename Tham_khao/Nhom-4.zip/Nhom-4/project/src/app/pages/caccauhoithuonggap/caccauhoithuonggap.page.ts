import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-caccauhoithuonggap',
  templateUrl: './caccauhoithuonggap.page.html',
  styleUrls: ['./caccauhoithuonggap.page.scss'],
})
export class CaccauhoithuonggapPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
