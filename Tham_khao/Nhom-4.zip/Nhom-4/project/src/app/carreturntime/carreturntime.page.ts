import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carreturntime',
  templateUrl: './carreturntime.page.html',
  styleUrls: ['./carreturntime.page.scss'],
})
export class CarreturntimePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
