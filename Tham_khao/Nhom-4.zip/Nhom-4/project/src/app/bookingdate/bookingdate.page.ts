import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingdate',
  templateUrl: './bookingdate.page.html',
  styleUrls: ['./bookingdate.page.scss'],
})
export class BookingdatePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
